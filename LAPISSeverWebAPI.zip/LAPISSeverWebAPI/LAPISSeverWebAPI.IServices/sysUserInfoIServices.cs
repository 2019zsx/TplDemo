﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using LAPISSeverWebAPI.Common.Message;
using LAPISSeverWebAPI.Model.DataModel;
using LAPISSeverWebAPI.Model.ViewModel;

namespace LAPISSeverWebAPI.IServices
{
    public interface sysUserInfoIServices : BASE.IBaseServices<sysUserInfoEntity>
    {
        //Task<PageModel<sysUserInfoEntity>> Verificationlogin(ViewLogin model);
    }
}