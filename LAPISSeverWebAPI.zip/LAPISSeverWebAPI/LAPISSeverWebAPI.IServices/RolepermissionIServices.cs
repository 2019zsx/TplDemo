﻿using System;
using System.Collections.Generic;
using System.Text;
using LAPISSeverWebAPI.Model.DataModel;

namespace LAPISSeverWebAPI.IServices
{
    public interface RolepermissionIServices : BASE.IBaseServices<RolePermissions>
    {
    }
}