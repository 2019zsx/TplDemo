﻿using System;
using System.Collections.Generic;
using System.Text;
using LAPISSeverWebAPI.Model.DataModel;

namespace LAPISSeverWebAPI.IServices
{
    public interface UserRoleIServices : BASE.IBaseServices<UserRoleEntity>
    {
    }
}