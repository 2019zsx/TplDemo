﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LAPISSeverWebAPI.Common.IsWhatExtenions;
using LAPISSeverWebAPI.Common.Message;
using LAPISSeverWebAPI.IServices;
using LAPISSeverWebAPI.Model.DataModel;
using LAPISSeverWebAPI.Model.ViewModel;
using LAPISSeverWebAPI.Repository.BASE;
using LAPISSeverWebAPI.Repository.UnitOfWork;

namespace LAPISSeverWebAPI.Services
{
    public class sysUserInfoServices : BASE.BaseServices<sysUserInfoEntity>, sysUserInfoIServices
    {
        public IBaseRepository<sysUserInfoEntity> dal;

        public IUnitOfWork unitOfWork;

        public sysUserInfoServices(IUnitOfWork _unitOfWork, IBaseRepository<sysUserInfoEntity> _dal)
        {
            dal = _dal;
            base.BaseDal = dal;
            unitOfWork = _unitOfWork;
        }

        /// <summary></summary>
        /// <returns></returns>
        public async Task<sysUserInfoEntity> Verificationlogin(ViewLogin model)
        {
            return null;
        }
    }
}