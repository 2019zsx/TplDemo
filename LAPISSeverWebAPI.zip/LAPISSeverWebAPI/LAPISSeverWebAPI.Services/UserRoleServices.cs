﻿using System;
using System.Collections.Generic;
using System.Text;
using LAPISSeverWebAPI.IServices;
using LAPISSeverWebAPI.Model.DataModel;
using LAPISSeverWebAPI.Repository.BASE;
using LAPISSeverWebAPI.Repository.UnitOfWork;

namespace LAPISSeverWebAPI.Services
{
    public class UserRoleServices : BASE.BaseServices<UserRoleEntity>, UserRoleIServices
    {
        public IBaseRepository<UserRoleEntity> dal;

        public UserRoleServices(IBaseRepository<UserRoleEntity> _dal)
        {
            dal = _dal;
            base.BaseDal = dal;
        }
    }
}