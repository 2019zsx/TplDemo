﻿using System;
using System.Collections.Generic;
using System.Text;
using LAPISSeverWebAPI.IServices;
using LAPISSeverWebAPI.Model.DataModel;
using LAPISSeverWebAPI.Repository.BASE;

namespace LAPISSeverWebAPI.Services
{
    public class RolepermissionServices : BASE.BaseServices<RolePermissions>, RolepermissionIServices
    {
        private IBaseRepository<RolePermissions> dal = null;

        public RolepermissionServices(IBaseRepository<RolePermissions> _dal)
        {
            dal = _dal;
            this.BaseDal = dal;
        }
    }
}