﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;

namespace LAPISSeverWebAPI.Common.HttpResponse
{
    /// <summary>请求地址</summary>
    public enum apiurl
    {
        [Description("马蜂有端口接口地址")]
        DSJURL,
    }
}