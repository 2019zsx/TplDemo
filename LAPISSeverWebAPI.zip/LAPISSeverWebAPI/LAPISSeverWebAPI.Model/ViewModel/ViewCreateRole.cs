﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAPISSeverWebAPI.Model.ViewModel
{
    /// <summary></summary>
    public class ViewCreateRole
    {
        /// <summary>角色名称</summary>
        public string roleName { get; set; }

        /// <summary>描述</summary>
        public string describe { get; set; }
    }
}