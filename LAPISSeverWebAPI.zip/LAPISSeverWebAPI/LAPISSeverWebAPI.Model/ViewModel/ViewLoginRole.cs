﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAPISSeverWebAPI.Model.ViewModel
{
    /// <summary>
    ///
    /// </summary>
    public class ViewLoginRole
    {
        /// <summary>
        /// 用户名
        /// </summary>
        public string uloginname { get; set; }

        /// <summary>
        ///  密码
        /// </summary>

        public string updw { get; set; }

        /// <summary>
        /// 验证码
        /// </summary>

        public string code { get; set; }
    }
}