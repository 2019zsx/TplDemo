﻿using System;
using System.Collections.Generic;
using System.Text;

namespace LAPISSeverWebAPI.Model.ViewModel
{
    /// <summary></summary>
    public class VIewLoginRolelist
    {
        /// <summary>角色id</summary>
        public int roleid { get; set; }

        /// <summary>角色名称</summary>

        public string rolename { get; set; }
    }
}