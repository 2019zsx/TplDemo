﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Text;
using LAPISSeverWebAPI.Model.DataModel;
using LAPISSeverWebAPI.Model.ViewModel;

namespace LAPISSeverWebAPI.Extensions.Mapper
{
    public class MapperProfiles : Profile
    {
        public MapperProfiles()
        {
            CreateMap<ViewCreateUser, sysUserInfoEntity>().ReverseMap();
        }
    }
}